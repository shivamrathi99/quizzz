import React, { useEffect, useState } from "react";
import axios from "axios";

export default function App() {
  const [q, setQ] = useState([]);

  function fun() {
    axios
      .get("http://localhost:3000/quiz")
      .then((res) => {
        return res.data;
      })
      .then((data) => {
        console.log("working", JSON.stringify(data));
        return setQ(JSON.stringify(data));
      })
      .catch((e) => console.log(e))
      .finally(() => console.log("Finally", q));
  }

  useEffect(() => {
    console.log("entering.");
    fun();
  }, 1);
  const questions = [
    {
      questionText: "Everything in react is a ",
      answerOptions: [
        { answerText: "Module", isCorrect: false },
        { answerText: "Component", isCorrect: true },
        { answerText: "Package", isCorrect: false },
        { answerText: "Class", isCorrect: false },
      ],
    },
    {
      questionText: "In which directory React components are saved?",
      answerOptions: [
        { answerText: "js/components", isCorrect: true },
        { answerText: "vendor/components", isCorrect: false },
        { answerText: "external/components", isCorrect: false },
        { answerText: "vendor", isCorrect: false },
      ],
    },
    {
      questionText: "How many elements does a react component return?",
      answerOptions: [
        { answerText: "2", isCorrect: false },
        { answerText: "1", isCorrect: false },
        { answerText: "Mutiple", isCorrect: true },
        { answerText: "None of these", isCorrect: false },
      ],
    },
    {
      questionText: "What does the webpack command do?",
      answerOptions: [
        {
          answerText: "Transpiles all the Javascript down into one file",
          isCorrect: false,
        },
        {
          answerText: "Runs react local development server.",
          isCorrect: false,
        },
        { answerText: "A module bundler", isCorrect: true },
        { answerText: "None of these", isCorrect: false },
      ],
    },
    {
      questionText: "ReactJs uses ____ to increase performance",
      answerOptions: [
        { answerText: "Original DOM", isCorrect: false },
        { answerText: "Virtual DOM", isCorrect: true },
        { answerText: "Both 1 and 2", isCorrect: false },
        { answerText: "None of above", isCorrect: false },
      ],
    },
  ];

  // const randomQ = Math.floor(Math.random() * 5) + 0;
  // console.log("HELLO", randomQ);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [showScore, setShowScore] = useState(false);
  const [score, setScore] = useState(0);

  const handleAnswerButtonClick = (isCorrect) => {
    if (isCorrect === true) {
      setScore(score + 1);
    }

    const nextQuestion = currentQuestion + 1;
    if (nextQuestion < questions.length) {
      setCurrentQuestion(nextQuestion);
    } else {
      setShowScore(true);
    }
  };

  return (
    <div className="app">
      {/* HINT: replace "false" with logic to display the 
      score when the user has answered all the questions */}
      {showScore ? (
        <div className="score-section">
          You scored {score} out of {questions.length}
        </div>
      ) : (
        <>
          <div className="question-section">
            <div className="question-count">
              <span>Question {currentQuestion + 1}</span>/{questions.length}
            </div>

            <div className="question-text">
              {questions[currentQuestion].questionText}
            </div>
          </div>

          <div className="answer-section">
            {questions[currentQuestion].answerOptions.map(
              (answerOption, index) => (
                <button
                  onClick={() =>
                    handleAnswerButtonClick(answerOption.isCorrect)
                  }
                >
                  {answerOption.answerText}
                </button>
              )
            )}
          </div>
        </>
      )}
    </div>
  );
}
